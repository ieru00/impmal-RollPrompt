# impmal-RollPrompt
Module that will allow you to prompt highlighted token owners for rolls based on your request.
