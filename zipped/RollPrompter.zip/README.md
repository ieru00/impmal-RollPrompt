# impmal-RollPrompt
Module that will bring up a dialog window which allows you to select skills to prompt your players to roll through chat!

Ask for roll via cards with all the Imperial Maledictum skills and specializations at a per token basis in one window.

Option to prompt all players at once, as well as privately request a private roll from players.


![Tokens Page](https://github.com/ieru00/impmal-RollPrompt/blob/main/z_bs_imgs/Token_Page.png?raw=true)
![Roll All Page](https://github.com/ieru00/impmal-RollPrompt/blob/main/z_bs_imgs/Roll_All_Page.png?raw=true)


